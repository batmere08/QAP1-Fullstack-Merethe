const { generatePassword, parseArguments } = require("../passwordGenerator");

describe('generatePassword', () => {
    test('The generated password is of the correct length', () => {

    });
})